//
//  SwingingApp.swift
//  Swinging
//
//  Created by Stephen DeStefano on 11/5/20.
//

import SwiftUI

@main
struct SwingingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
