//
//  Parallax_EffectApp.swift
//  Parallax Effect
//
//  Created by Stephen DeStefano on 11/4/20.
//

import SwiftUI

@main
struct Parallax_EffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
