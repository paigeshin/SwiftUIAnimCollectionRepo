//
//  Twinkling_StarsApp.swift
//  Twinkling Stars
//
//  Created by Stephen DeStefano on 11/5/20.
//

import SwiftUI

@main
struct Twinkling_StarsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
