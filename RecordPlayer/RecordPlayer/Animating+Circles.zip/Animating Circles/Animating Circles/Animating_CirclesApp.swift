//
//  Animating_CirclesApp.swift
//  Animating Circles
//
//  Created by Stephen DeStefano on 10/29/20.
//

import SwiftUI

@main
struct Animating_CirclesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
