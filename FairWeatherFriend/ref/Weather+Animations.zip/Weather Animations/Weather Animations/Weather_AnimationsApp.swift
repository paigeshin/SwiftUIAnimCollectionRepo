//
//  Weather_AnimationsApp.swift
//  Weather Animations
//
//  Created by Stephen DeStefano on 11/10/20.
//

import SwiftUI

@main
struct Weather_AnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
