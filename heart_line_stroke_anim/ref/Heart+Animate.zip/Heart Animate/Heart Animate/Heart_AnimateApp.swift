//
//  Heart_AnimateApp.swift
//  Heart Animate
//
//  Created by Stephen DeStefano on 12/29/20.
//

import SwiftUI

@main
struct Heart_AnimateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
