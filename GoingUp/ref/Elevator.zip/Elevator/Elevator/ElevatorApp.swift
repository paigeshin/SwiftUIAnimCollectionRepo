//
//  ElevatorApp.swift
//  Elevator
//
//  Created by Stephen DeStefano on 11/9/20.
//

import SwiftUI

@main
struct ElevatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
