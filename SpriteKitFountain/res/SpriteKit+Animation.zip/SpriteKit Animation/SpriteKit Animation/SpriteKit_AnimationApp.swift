//
//  SpriteKit_AnimationApp.swift
//  SpriteKit Animation
//
//  Created by Stephen DeStefano on 11/2/20.
//

import SwiftUI

@main
struct SpriteKit_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
