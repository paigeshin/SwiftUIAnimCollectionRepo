//
//  FoldAnimationApp.swift
//  FoldAnimation
//
//  Created by Amos Gyamfi on 29.4.2021.
//

import SwiftUI

@main
struct FoldAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
