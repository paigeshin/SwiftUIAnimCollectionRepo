//
//  PencilLoaderApp.swift
//  PencilLoader
//
//  Created by Amos Gyamfi on 7.8.2021.
//

import SwiftUI

@main
struct PencilLoaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
