//
//  ColorWheelApp.swift
//  ColorWheel
//
//  Created by Amos Gyamfi on 22.6.2021.
//

import SwiftUI

@main
struct ColorWheelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
