//
//  LoadingIndicatorApp.swift
//  LoadingIndicator
//
//  Created by Amos Gyamfi on 28.5.2021.
//

import SwiftUI

@main
struct LoadingIndicatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
