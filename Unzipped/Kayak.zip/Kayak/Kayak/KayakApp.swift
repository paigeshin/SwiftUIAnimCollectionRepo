//
//  KayakApp.swift
//  Kayak
//
//  Created by Amos Gyamfi on 23.8.2020.
//

import SwiftUI

@main
struct KayakApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
