//
//  LockScreenApp.swift
//  LockScreen
//
//  Created by Amos Gyamfi on 23.10.2020.
//

import SwiftUI

@main
struct LockScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
