//
//  WeatherSunWindApp.swift
//  WeatherSunWind
//
//  Created by Amos Gyamfi on 2.3.2021.
//

import SwiftUI

@main
struct WeatherSunWindApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
