//
//  WeatherNotificationsAnimationApp.swift
//  WeatherNotificationsAnimation
//
//  Created by Amos Gyamfi on 18.5.2021.
//

import SwiftUI

@main
struct WeatherNotificationsAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
