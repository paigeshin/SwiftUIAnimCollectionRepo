//
//  breathApp.swift
//  breath
//
//  Created by Amos Gyamfi on 17.7.2020.
//

import SwiftUI

@main
struct breathApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
