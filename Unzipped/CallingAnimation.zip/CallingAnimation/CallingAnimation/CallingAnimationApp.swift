//
//  CallingAnimationApp.swift
//  CallingAnimation
//
//  Created by Amos Gyamfi on 27.9.2020.
//

import SwiftUI

@main
struct CallingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
