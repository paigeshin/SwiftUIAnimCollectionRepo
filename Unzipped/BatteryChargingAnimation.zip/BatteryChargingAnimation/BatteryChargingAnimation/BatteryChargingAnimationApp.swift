//
//  BatteryChargingAnimationApp.swift
//  BatteryChargingAnimation
//
//  Created by Amos Gyamfi on 21.4.2021.
//

import SwiftUI

@main
struct BatteryChargingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
