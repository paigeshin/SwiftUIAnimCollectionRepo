//
//  blankSwiftuiApp.swift
//  blankSwiftui
//
//  Created by Amos Gyamfi on 30.1.2021.
//

import SwiftUI

@main
struct blankSwiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
