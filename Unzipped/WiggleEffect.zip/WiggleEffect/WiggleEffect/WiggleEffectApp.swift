//
//  WiggleEffectApp.swift
//  WiggleEffect
//
//  Created by Amos Gyamfi on 16.3.2021.
//

import SwiftUI

@main
struct WiggleEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
