//
//  NotificationView.swift
//  OrientOnPath WatchKit Extension
//
//  Created by Amos Gyamfi on 21.1.2021.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
