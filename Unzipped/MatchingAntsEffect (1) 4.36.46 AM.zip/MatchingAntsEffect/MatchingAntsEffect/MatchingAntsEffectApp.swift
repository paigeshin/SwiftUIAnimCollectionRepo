//
//  MatchingAntsEffectApp.swift
//  MatchingAntsEffect
//
//  Created by Amos Gyamfi on 3.5.2021.
//

import SwiftUI

@main
struct MatchingAntsEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
