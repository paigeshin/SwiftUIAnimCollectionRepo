//
//  RestartAppApp.swift
//  RestartApp
//
//  Created by paige on 2021/12/19.
//

import SwiftUI

@main
struct RestartAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
