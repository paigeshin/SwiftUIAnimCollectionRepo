//
//  ArcMenuApp.swift
//  ArcMenu
//
//  Created by Amos Gyamfi on 17.2.2021.
//

import SwiftUI

@main
struct ArcMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
