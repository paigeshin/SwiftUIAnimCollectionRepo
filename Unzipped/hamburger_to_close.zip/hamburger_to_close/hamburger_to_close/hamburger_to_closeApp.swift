//
//  hamburger_to_closeApp.swift
//  hamburger_to_close
//
//  Created by Amos Gyamfi on 30.3.2021.
//

import SwiftUI

@main
struct hamburger_to_closeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
