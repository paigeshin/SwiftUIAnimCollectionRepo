//
//  PassiveIncomeApp.swift
//  PassiveIncome
//
//  Created by Amos Gyamfi on 23.3.2021.
//

import SwiftUI

@main
struct PassiveIncomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
