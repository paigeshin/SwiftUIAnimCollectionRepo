//
//  ClappingHandsEmojiApp.swift
//  ClappingHandsEmoji
//
//  Created by amos.gyamfi@getstream.io on 4.12.2021.
//

import SwiftUI

@main
struct ClappingHandsEmojiApp: App {
    var body: some Scene {
        WindowGroup {
            ClappingHandsEmojiView()
        }
    }
}
