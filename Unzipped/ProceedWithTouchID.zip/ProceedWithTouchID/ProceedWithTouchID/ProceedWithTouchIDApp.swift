//
//  ProceedWithTouchIDApp.swift
//  ProceedWithTouchID
//
//  Created by Amos Gyamfi on 13.2.2021.
//

import SwiftUI

@main
struct ProceedWithTouchIDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
