//
//  JustBreathApp.swift
//  JustBreath
//
//  Created by Amos Gyamfi on 9.11.2020.
//

import SwiftUI

@main
struct JustBreathApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
