//
//  Bi_DirectionalArcMenuApp.swift
//  Bi-DirectionalArcMenu
//
//  Created by Amos Gyamfi on 25.2.2021.
//

import SwiftUI

@main
struct Bi_DirectionalArcMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
