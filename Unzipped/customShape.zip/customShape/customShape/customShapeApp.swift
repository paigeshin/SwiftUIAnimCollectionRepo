//
//  customShapeApp.swift
//  customShape
//
//  Created by Amos Gyamfi on 30.12.2020.
//

import SwiftUI

@main
struct customShapeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
