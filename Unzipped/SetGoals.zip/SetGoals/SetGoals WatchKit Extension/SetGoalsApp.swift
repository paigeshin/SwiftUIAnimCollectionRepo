//
//  SetGoalsApp.swift
//  SetGoals WatchKit Extension
//
//  Created by Amos Gyamfi on 19.2.2021.
//

import SwiftUI

@main
struct SetGoalsApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
        }
    }
}
