//
//  BikeAnimationApp.swift
//  BikeAnimation
//
//  Created by Amos Gyamfi on 24.4.2021.
//

import SwiftUI

@main
struct BikeAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
