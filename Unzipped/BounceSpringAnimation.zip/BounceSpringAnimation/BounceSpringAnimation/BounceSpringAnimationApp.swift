//
//  BounceSpringAnimationApp.swift
//  BounceSpringAnimation
//
//  Created by Amos Gyamfi on 4.2.2021.
//

import SwiftUI

@main
struct BounceSpringAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
