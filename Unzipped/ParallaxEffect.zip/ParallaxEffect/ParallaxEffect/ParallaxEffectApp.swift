//
//  ParallaxEffectApp.swift
//  ParallaxEffect
//
//  Created by Amos Gyamfi on 16.8.2020.
//

import SwiftUI

@main
struct ParallaxEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
