//
//  MS_TeamsStyleCallingAnimationApp.swift
//  MS_TeamsStyleCallingAnimation
//
//  Created by Amos Gyamfi on 20.5.2021.
//

import SwiftUI

@main
struct MS_TeamsStyleCallingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
