//
//  FaceBook_NotificationApp.swift
//  FaceBook_Notification
//
//  Created by Amos Gyamfi on 8.4.2021.
//

import SwiftUI

@main
struct FaceBook_NotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
