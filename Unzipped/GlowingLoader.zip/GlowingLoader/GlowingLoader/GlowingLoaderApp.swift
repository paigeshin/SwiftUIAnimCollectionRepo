//
//  GlowingLoaderApp.swift
//  GlowingLoader
//
//  Created by Amos Gyamfi on 20.1.2021.
//

import SwiftUI

@main
struct GlowingLoaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
