//
//  KeyFrameAnimationApp.swift
//  KeyFrameAnimation
//
//  Created by Amos Gyamfi on 13.8.2021.
//

import SwiftUI

@main
struct KeyFrameAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
