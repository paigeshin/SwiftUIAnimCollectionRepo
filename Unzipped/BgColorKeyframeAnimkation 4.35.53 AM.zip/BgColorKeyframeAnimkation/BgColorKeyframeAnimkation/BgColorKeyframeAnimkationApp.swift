//
//  BgColorKeyframeAnimkationApp.swift
//  BgColorKeyframeAnimkation
//
//  Created by Amos Gyamfi on 14.8.2021.
//

import SwiftUI

@main
struct BgColorKeyframeAnimkationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
