//
//  GradientStartEndPointsApp.swift
//  GradientStartEndPoints
//
//  Created by Amos Gyamfi on 5.7.2021.
//

import SwiftUI

@main
struct GradientStartEndPointsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
