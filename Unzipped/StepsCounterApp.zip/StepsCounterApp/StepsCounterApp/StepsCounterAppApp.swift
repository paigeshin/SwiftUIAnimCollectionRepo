//
//  StepsCounterAppApp.swift
//  StepsCounterApp
//
//  Created by Amos Gyamfi on 15.2.2021.
//

import SwiftUI

@main
struct StepsCounterAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
