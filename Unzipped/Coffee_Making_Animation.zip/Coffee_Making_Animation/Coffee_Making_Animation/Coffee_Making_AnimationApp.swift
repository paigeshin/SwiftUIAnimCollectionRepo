//
//  Coffee_Making_AnimationApp.swift
//  Coffee_Making_Animation
//
//  Created by Amos Gyamfi on 20.4.2021.
//

import SwiftUI

@main
struct Coffee_Making_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
