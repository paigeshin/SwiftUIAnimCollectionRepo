//
//  SendingIndicatorAnimationApp.swift
//  SendingIndicatorAnimation
//
//  Created by Amos Gyamfi on 15.7.2021.
//

import SwiftUI

@main
struct SendingIndicatorAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
