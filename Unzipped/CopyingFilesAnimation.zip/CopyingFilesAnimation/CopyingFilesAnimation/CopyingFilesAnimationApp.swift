//
//  CopyingFilesAnimationApp.swift
//  CopyingFilesAnimation
//
//  Created by Amos Gyamfi on 16.7.2021.
//

import SwiftUI

@main
struct CopyingFilesAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
