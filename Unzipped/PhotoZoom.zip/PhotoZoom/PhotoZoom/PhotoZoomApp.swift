//
//  PhotoZoomApp.swift
//  PhotoZoom
//
//  Created by Amos Gyamfi on 24.2.2021.
//

import SwiftUI

@main
struct PhotoZoomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
