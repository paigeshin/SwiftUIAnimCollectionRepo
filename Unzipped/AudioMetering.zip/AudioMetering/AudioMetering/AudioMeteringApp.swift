//
//  AudioMeteringApp.swift
//  AudioMetering
//
//  Created by Amos Gyamfi on 13.2.2021.
//

import SwiftUI

@main
struct AudioMeteringApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
