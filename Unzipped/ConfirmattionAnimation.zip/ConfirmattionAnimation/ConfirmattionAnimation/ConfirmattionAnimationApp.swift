//
//  ConfirmattionAnimationApp.swift
//  ConfirmattionAnimation
//
//  Created by Amos Gyamfi on 8.8.2021.
//

import SwiftUI

@main
struct ConfirmattionAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
