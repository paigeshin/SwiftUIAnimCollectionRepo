//
//  SlideToPowerOffApp.swift
//  SlideToPowerOff
//
//  Created by Amos Gyamfi on 6.7.2021.
//

import SwiftUI

@main
struct SlideToPowerOffApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
