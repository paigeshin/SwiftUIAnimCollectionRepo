//
//  firstSwiftUIApp.swift
//  firstSwiftUI
//
//  Created by Amos Gyamfi on 29.1.2021.
//

import SwiftUI

@main
struct firstSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
