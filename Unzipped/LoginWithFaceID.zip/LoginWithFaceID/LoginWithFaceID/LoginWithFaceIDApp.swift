//
//  LoginWithFaceIDApp.swift
//  LoginWithFaceID
//
//  Created by Amos Gyamfi on 13.2.2021.
//

import SwiftUI

@main
struct LoginWithFaceIDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
