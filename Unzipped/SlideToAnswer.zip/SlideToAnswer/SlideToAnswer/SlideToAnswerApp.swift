//
//  SlideToAnswerApp.swift
//  SlideToAnswer
//
//  Created by Amos Gyamfi on 14.7.2021.
//

import SwiftUI

@main
struct SlideToAnswerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
