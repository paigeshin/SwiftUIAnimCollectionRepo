//
//  Spring_Animation_in_DepthApp.swift
//  Spring_Animation_in_Depth
//
//  Created by Amos Gyamfi on 30.1.2021.
//

import SwiftUI

@main
struct Spring_Animation_in_DepthApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
