//
//  Kid_on_SwingApp.swift
//  Kid_on_Swing
//
//  Created by Amos Gyamfi on 30.10.2020.
//

import SwiftUI

@main
struct Kid_on_SwingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
