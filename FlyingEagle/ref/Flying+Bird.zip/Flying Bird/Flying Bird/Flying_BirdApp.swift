//
//  Flying_BirdApp.swift
//  Flying Bird
//
//  Created by Stephen DeStefano on 11/2/20.
//

import SwiftUI

@main
struct Flying_BirdApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
