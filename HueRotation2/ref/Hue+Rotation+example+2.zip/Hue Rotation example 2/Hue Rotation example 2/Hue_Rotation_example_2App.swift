//
//  Hue_Rotation_example_2App.swift
//  Hue Rotation example 2
//
//  Created by Stephen DeStefano on 11/2/20.
//

import SwiftUI

@main
struct Hue_Rotation_example_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
