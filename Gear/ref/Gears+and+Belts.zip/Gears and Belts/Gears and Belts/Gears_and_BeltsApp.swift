//
//  Gears_and_BeltsApp.swift
//  Gears and Belts
//
//  Created by Stephen DeStefano on 11/10/20.
//

import SwiftUI

@main
struct Gears_and_BeltsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
