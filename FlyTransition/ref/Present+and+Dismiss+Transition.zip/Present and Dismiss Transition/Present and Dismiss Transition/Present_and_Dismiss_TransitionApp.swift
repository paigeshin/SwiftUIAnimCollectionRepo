//
//  Present_and_Dismiss_TransitionApp.swift
//  Present and Dismiss Transition
//
//  Created by Stephen DeStefano on 11/3/20.
//

import SwiftUI

@main
struct Present_and_Dismiss_TransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
