//
//  WavesApp.swift
//  Waves
//
//  Created by Stephen DeStefano on 11/11/20.
//

import SwiftUI

@main
struct WavesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
